#include "Equations.h"

int main(void)
{

	int option = 0;
	int user_input = 0;
	int total_points = 0;
	int difficulty = 0;
	char initials[4] = { '\0' };
	Stats SUPERuser = { 0, 0 };
	FILE *output = NULL;

	srand((int)time(NULL));

	print_SUPERMATH(); //prints the characters at the top of the screen i made
	output = fopen("SUPERstats.txt", "w"); //opens the stats file for writing
	option = run_menu(); // runs the menu that is seen when the program starts
	determine_operation(option, initials); //recieves the initials of the user and the option that the user selected from the menu

	get_difficulty(&difficulty); //gets the difficulty from the user once the user starts the math game
	system("cls"); //clear screen

	if (difficulty == 1) // opens level 1 
	{
		level_1_problem(SUPERuser, &total_points); // pass in the stat array and the total points pointer
		do
		{
			system("cls");
			printf("Enter 1 to move up or 0 to end game: "); //go to level 2 or quit game
			scanf("%d", &user_input);
		} while ((user_input != 1) && (user_input != 0)); // make sure the user input is valid
		if (user_input == 1)
		{
			difficulty = 2; //difficulty changed to 2
			system("cls");
		}
	}

	if (difficulty == 2)//opens level 2
	{
		level_2_problem(SUPERuser, &total_points); // pass in the stat array and the total points pointer
		do
		{
			system("cls");
			printf("Enter 1 to move up or 0 to end game: ");//go to level 3 or quit game
			scanf("%d", &user_input);
		} while ((user_input != 1) && (user_input != 0)); // user input must be valid

		if (user_input == 1)
		{
			difficulty = 3; //difficlty changed to 3
			system("cls");
		}
	}

	if (difficulty == 3) //opens level 3
	{
		level_3_problem(SUPERuser, &total_points); // pass in the stat array and the total points pointer
		do
		{
			system("cls");
			printf("Enter 1 to move up or 0 to end game: "); // go to level 4 or quit the game
			scanf("%d", &user_input);
		} while ((user_input != 1) && (user_input != 0));//user input must be valid

		if (user_input == 1)
		{
			difficulty = 4; //difficulty now changed to 4
			system("cls");
		}
	}

	if (difficulty == 4) //opens level 4
	{
		level_4_problem(SUPERuser, &total_points);// pass in the stat array and the total points pointer
		do
		{
			system("cls");
			printf("Enter 1 to move up or 0 to end game: "); //move to level 5 or quit
			scanf("%d", &user_input);
		} while ((user_input != 1) && (user_input != 0)); //user input must be valid

		if (user_input == 1)
		{
			difficulty = 5; //difficulty now changed to 5
			system("cls");
		}

	}

	if (difficulty == 5)//opens level 5
	{
		level_5_problem(SUPERuser, &total_points); // pass in the stat array and the total points pointer
	}

	SUPERuser.points = total_points; //sets the struct value equal to the total points value
	print_stats(output, SUPERuser, initials); //prints the user initals and total points to a stat file

	fclose(output); //closes stats file

	return 0;
}