#ifndef EQUATIONS_H
#define EQUATIONS_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h> 
#include <stdlib.h> 
#include <time.h> 


typedef struct stats // holds user stats
{
	int total_questions;
	int points;
} Stats;

void print_SUPERMATH(void);
void display_menu(void);
int get_option(void);
int is_valid(int option);
int run_menu(void);
void determine_operation(int option, char initials[]);
void print_stats(FILE *output, Stats SUPERuser, char initials[]);

void user_initials(char initials[]);
void get_difficulty(int *difficulty);
int generate_single_positive_term(void);
int generate_positive_negative_term(void);
int generate_2_digit_term(void);
int generate_3_digit_term(void);
int control_total_points(int difficulty, int *points, int true_false);

void level_1_problem(Stats user, int *total_points_ptr);
void level_2_problem(Stats user, int *total_points_ptr);
void level_3_problem(Stats user, int *total_points_ptr);
void level_4_problem(Stats user, int *total_points_ptr);
void level_5_problem(Stats user, int *total_points_ptr);

void run_math_tutorial(void);


#endif 