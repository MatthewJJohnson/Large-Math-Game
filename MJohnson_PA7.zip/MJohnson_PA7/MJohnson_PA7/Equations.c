#include "Equations.h"
//this function prints out the menu so that the user 
//knows what number to enter for a specific choice
void display_menu(void)
{
	printf("Welcome to the SUPER MATH GAME.\n");
	printf("1. SUPER MATH GAME rules.\n");
	printf("2. Enter your initials.\n");
	printf("3. Start SUPER MATH GAME.\n");
	printf("4. Save and Exit.\n");
	printf("5. A tutorial for basic math problems.\n");
}
//This function recieves the desired choice from the user
int get_option(void)
{
	int option = 0;

	scanf("%d", &option); //gets the option from the user
	return option;
}
//this function makes sure that the option is valid, 
//meaning that there is a choice that represents the number they chose.
int is_valid(int option)
{
	int status = 1;

	if ((option < 1) || (option > 5))
	{
		status = 0; //invalid
	}
	return status;
}
//This function does not let the user proceed in the prgoram without selecting a valid option. 
//It displays the menu and recieves an option. This function conrols the menu.
int run_menu(void)
{
	int status = 0, option = 0;
	do
	{
		display_menu(); // display menu
		option = get_option(); // get option from user
		status = is_valid(option); // check the validity of the option
	} while (status == 0); // status != 1
	return option;
}
//This function progresses the program depending on the input entered. It either makes the user input their initials, 
//select a difficulty, exits the program, or sends them to the tutorial.
void determine_operation(int option, char initials[])
{
	system("cls");
	switch (option)
	{
	case 1: 
		printf("Problems within the levels increase in difficulty based on correct answers!\n\n");
		printf("1. Easy: addition and subtraction problems with 3 terms.\n");
		printf("2. Fair: Multiplication problems with single digits and two terms.\n");
		printf("3. Intermediate: Single digit division with two terms.\n");
		printf("4. Hard: Mix of all operations with three terms.\n");
		printf("5. Impossible: Math problems with four terms and a mix of all operations.\n");
		printf("\n\n");
		option = run_menu();
		determine_operation(option, initials);//run menu again for new input with new option
		break;
	case 2:
		user_initials(initials);
		system("cls");
		option = run_menu();
		determine_operation(option, initials); //run menu again for new input with new option
		break;
	case 3: 
		break;
	case 4: 
		printf("Math is hard. Feel free to come try it again later. Goodbye!\n");
		exit(1); //exit the program
	case 5: //contains brief description of math functions before being sent to the tutorial game
		printf("Begin Tutorial:\n");
		printf("Addition (+) is an increasing operation. When adding two numbers, you combine their individual values.\n");
		printf("Value (1) + Value (3) = 4. OR Value(1) + Value(1+1+1) = Value(1+1+1+1)\n");
		printf("\n");
		printf("Subtraction (-) is an decreasing operation. When subtracting two numbers, you take away a term's individual values.\n");
		printf("Value (1) - Value (3) = -2. OR Value(1) - Value(1+1+1) = Value(1-(1+1+1))\n");
		printf("Watch out! The negative of a negative is the opposite positive number. For real numbers, 1 -(-5) = +6\n");
		printf("Having two negative signs together makes a positive.\n");
		printf("\n");
		printf("Multiplication is the addition of a number multiple times.\n");
		printf("This example is 2 multiplied 3 times.\n");
		printf("Value (2) * Value (3) = 6. OR Answer (2+2+2) = 6\n");
		printf("Watch out! The multiplication of two negative numbers is the opposite positive number. For real numbers, -5 * -5 = +25\n");
		printf("\n");
		printf("Division is the number of times one term can go into another.\n");
		printf("This example is 8 divided by 3.\n");
		printf("Value (8) / Value (3) = 2R2. 3 goes into 8 two times before going over 8. (3+3 = 6)\n");
		printf("To find the remainder, see what is left over. After going into adding 3 two times, we have 6. This isnt 8, but it's as close as three can get without going over. In order to get to 8, we would now need a 2. So the remainder is 2.\n");
		printf("Watch out! The division of two negative numbers is the opposite positive number. For real numbers, -5 / -5 = 1R0\n");
		printf("\n");
		system("pause");
		system("cls");
		printf("Let's go try this ourselves.\n");
		system("pause");
		system("cls");
		run_math_tutorial(); //tutorial begins
		system("cls");
		option = run_menu();
		determine_operation(option, initials); //after tutorial ends, a new optin is required
	default:
		break;
	}
}
//this function recieves 3 characters from the user that will be their initials.
void user_initials(char initials[])
{
	char first = '\0', middle = '\0', last = '\0';

	system("cls");
	printf("Enter your initials (3 letters): ");
	scanf(" %c%c%c", &first, &middle, &last);

	initials[0] = first;
	initials[1] = middle;
	initials[2] = last; //construct a 3 length array to hold the initials for the stats output later

}
//This function prompts the user to choose a starting difficulty and shows them the list of possible difficulties.
//If they do not choose a valid option, they are prompted again.
void get_difficulty(int *difficulty)
{
	int difficult = 0;

	do
	{
		printf("Lets see what you got! Enter a starting difficulty.\n");
		printf("1. Easy: addition and subtraction problems with 3 terms.\n");
		printf("2. Fair: Multiplication problems with single digits and two terms.\n");
		printf("3. Intermediate: Single digit division with two terms.\n");
		printf("4. Hard: Mix of all operations with three terms.\n");
		printf("5. Impossible: Math problems with four terms and a mix of all operations.\n");
		scanf("%d", &difficult);
	} while ((difficult < 1) || (difficult > 5)); //prompt again if not 1-5

	*difficulty = difficult; //stores the difficulty as a pointer to be used later
}
//this function generates a number 1-9
int generate_single_positive_term(void)
{
	int num = 0;

	num = rand() % 10; //random 1-9

	return num;
}
//this function generates a -9 to -9
int generate_positive_negative_term(void)
{
	int num = 0;

	num = (rand() % 19) - 9; //to get a -9, the rand operator would produce a 0 and then subract 9.

	return num;
}
//this function generates a 1-99
int generate_2_digit_term(void)
{
	int num = 0;

	num = (rand() % 199) - 99; //to get a -99, the rand operator would produce a 0 and then subract 99.

	return num;
}
//this function generates a 1-999
int generate_3_digit_term(void)
{
	int num = 0;

	num = (rand() % 1999) - 999; //to get a -999, the rand operator would produce a 0 and then subract 999.

	return num;
}
//This function controls the total points pointer, and adds or subtract the correct amount of points.
int control_total_points(int difficulty, int *points, int true_false)
{
	if (difficulty == 1) //while they are in the first sublevel of a level
	{
		if (true_false == 1)
		{
			*points = *points + 1; //add a point if they are correct
		}
		else if (true_false == 0)
		{
			*points = *points - 1; //subtract a point if they are wrong
		}
		return 1;
	}
	else if (difficulty == 2) //while they are in the second sublevel of a level
	{
		if (true_false == 1)
		{
			*points = *points + 2; // add 2 points for correct
		}
		else if (true_false == 0)
		{
			*points = *points - 2;// subtract 2 for wrong
		}
		return 2;
	}
	else //while they are in sublevel 3 of a level
	{
		if (true_false == 1)
		{
			*points = *points + 3; //add 3 points
		}
		else if (true_false == 0)
		{
			*points = *points - 3;//subtract 3 points
		}
		return 3;
	}
}
//This function controls the level 1 difficulty of the game. It increases the points 
//after each question while getting harder after a certain amount of quetions.
void level_1_problem(Stats user, int *total_points_ptr)
{
	int term1 = 0, term2 = 0, term3 = 0, question_index = 0;
	int question_number = 1;
	char sign1 = '\0', sign2 = '\0';
	int answer = 0, user_answer = 0, score = 1, difficulty = 0, point = 0, problem_type;

	for (question_index = 0; question_index < 10; question_index++) // makes 10 questions of single digit problems
	{

		term1 = generate_single_positive_term();
		term2 = generate_single_positive_term();
		term3 = generate_single_positive_term();

		if (score < 4) // difficulty is 1 if they have less than 4 points (corect answers)
		{
			difficulty = 1;
			sign1 = '+';
			sign2 = '+';
		}
		else if ((score >= 4) && (score < 7)) //for 4-7 points the difficulty is 2
		{
			difficulty = 2;
			sign1 = '-';
			sign2 = '-';
		}
		else  //for anything greater than 7 points, the difficulty is 3
		{
			difficulty = 3;
			if ((rand() % 2) == 0) //randomly choose which type of level 3 problem to ask
			{
				problem_type = 0;
				sign1 = '+';
				sign2 = '-';
			}
			else
			{
				problem_type = 1;
				sign1 = '-';
				sign2 = '+';
			}
		}

		if (difficulty == 1) //provides answer for difficulty 1
		{
			answer = term1 + term2 +term3;
		}
		else if (difficulty == 2)
		{
			answer = term1 - term2 - term3; //provides answer for difficulty 2
		}
		else if ((difficulty == 3) && (problem_type == 0))
		{
			answer = term1 + term2 - term3; //provides answer for difficulty 3 problem type 1
		}
		else if ((difficulty == 3) && (problem_type == 1)) 
		{
			answer = term1 - term2 + term3; //provides answer for difficulty 3 problem type 2
		}

		printf("Question %d: ", question_number); //prints the question number
		printf("%d %c %d %c %d = ", term1, sign1, term2, sign2, term3, answer); //prints the digit, the math sign, the second digit, the second math sign, and the third digit.
		scanf("%d", &user_answer); //scan the answer in from the user

		if (user_answer != answer) // incorrect
		{
			printf("That is incorrect.\n");
			printf("The correct answer was %d\n", answer); //display correct answer

			point = control_total_points(difficulty, total_points_ptr, 0); //pass in the total points ptr and subtrract the correct amount of points
			score--; // decreases difficulty within level
			question_number++; //increase question number

			printf("-%d points subtracted from total score\n", point); //tell them how many points they lost

			system("pause");
			system("cls");
		}
		else // correct
		{
			printf("That is correct!\n");

			point = control_total_points(difficulty, total_points_ptr, 1); //pass in the total points ptr and add the correct amount of points
			score++; // increases difficulty within level
			question_number++; //increase question number

			printf("+%d points added to total score\n", point); //tell them how many points they gained

			system("pause");
			system("cls");
		}

	}
}
//This function controls the level 2 difficulty of the game. It increases the points 
//after each question while getting harder after a certain amount of quetions.
void level_2_problem(Stats user, int *total_points_ptr)
{
	int term1 = 0, term2 = 0, question_index = 0;
	int question_number = 1;
	char sign1 = '\0';
	int answer = 0, user_answer = 0, score = 1, difficulty = 0, point = 0;

	for (question_index = 0; question_index < 10; question_index++) // makes 10 questions
	{
		if (score < 3) // difficulty is 1 when less than 3 questions
		{
			difficulty = 1;
			sign1 = '*';
			term1 = 0;
			term2 = generate_single_positive_term();
			while (term2 == 0)
			{
				term2 = generate_single_positive_term();
			}

		}
		else if ((score >= 3) && (score < 5))
		{
			difficulty = 2;
			sign1 = '*';
			term2 = 0;
			term1 = generate_single_positive_term();
			while (term1 == 0)
			{
				term1 = generate_single_positive_term();
			}
		}
		else
		{
			difficulty = 3;
			sign1 = '*';
			term2 = generate_single_positive_term();
			term1 = generate_single_positive_term();
			while ((term1 == 0) || (term2 == 0))
			{
				term2 = generate_single_positive_term();
				term1 = generate_single_positive_term();
			}
		}

		if (difficulty == 1)
		{
			answer = 0;
		}
		else if (difficulty == 2)
		{
			answer = 0;
		}
		else 
		{
			answer = term1 *term2;
		}
		

		printf("Question %d: ", question_number);
		printf("%d %c %d = ", term1, sign1, term2, answer);
		scanf("%d", &user_answer);

		if (user_answer != answer) // incorrect
		{
			printf("That is incorrect.\n");
			printf("The correct answer was %d\n", answer);

			point = control_total_points(difficulty, total_points_ptr, 0);
			score--; // decreases difficulty within level
			question_number++;

			printf("-%d points subtracted from total score\n", point);

			system("pause");
			system("cls");
		}
		else // correct
		{
			printf("That is correct!\n");

			point = control_total_points(difficulty, total_points_ptr, 1);
			score++; // increases difficulty within level
			question_number++;

			printf("+%d points added to total score\n", point);

			system("pause");
			system("cls");
		}

	}
}
//This function controls the level 3 difficulty of the game. It increases the points 
//after each question while getting harder after a certain amount of quetions.
void level_3_problem(Stats user, int *total_points_ptr)
{
	int term1 = 0, term2 = 0, truefrac = 0, remainder = 0, question_index = 0;
	int question_number = 1;
	char sign1 = '\0', user_remainder_notation = '\0';
	int answer = 0, user_truefrac = 0, user_remainder = 0, score = 1, difficulty = 0, point = 0;

	for (question_index = 0; question_index < 10; question_index++) // makes 10 questions
	{
		if (score < 3) // while score is less than 3 difficulty is 1
		{
			difficulty = 1;
			sign1 = '/';
			term1 = generate_single_positive_term();
			term2 = 2;
			while (term1 == 0)
			{
				term1 = generate_single_positive_term();
			}

		}
		else if ((score >= 3) && (score < 5))
		{
			difficulty = 2;
			sign1 = '/';
			term2 = 4;
			term1 = generate_single_positive_term();
			while (term1 == 0)
			{
				term1 = generate_single_positive_term();
			}
		}
		else
		{
			difficulty = 3;
			sign1 = '/';
			term1 = generate_single_positive_term();
			term2 = generate_single_positive_term();
			while (term2 == 0)
			{
				term2 = generate_single_positive_term();
			}
		}

		truefrac = term1 / term2;
		if (truefrac == 0)
		{
			remainder = term1;
		}
		else
		{
			remainder = term1 % term2;
		}

		system("cls");
		do
		{
			printf("Question %d\n", question_number);
			printf("Example Answer: 10 / 4 = 2 R 2\n"); //example notation
			printf("%d / %d = ", term1, term2);
			scanf("%d %c %d", &user_truefrac, &user_remainder_notation, &user_remainder);

			if ((user_remainder_notation != 'R') && (user_remainder_notation != 'r')) // makes sure the user uses 'R' or 'r'
			{
				printf("You need an 'R' or 'r' seperating your digits.\n");
				printf("Pay attention and try agian.\n");
			}
		} while ((user_remainder_notation != 'R') && (user_remainder_notation != 'r')); //prompt again to use the remainder notation

		if ((user_truefrac != truefrac) || (user_remainder != remainder))
		{
			if (user_truefrac != truefrac) // incorrect
			{
				printf("Your first digit was wrong.\n");
				printf("The correct answer was -%d- R %d\n", truefrac, remainder);
				system("pause");
			}
			if (user_remainder != remainder)
			{
				printf("Your second digit was wrong.\n");
				printf("The correct answer was %d R -%d-\n", truefrac, remainder);
				system("pause");
			}
			point = control_total_points(difficulty, total_points_ptr, 0);
			score--; // decreases difficulty within level
			question_number++;

			printf("-%d points subtracted from total score\n", point);
			system("cls");
		}
		else // correct
		{
			printf("That is correct!\n");

			point = control_total_points(difficulty, total_points_ptr, 1);
			score++; // increases difficulty within level
			question_number++;

			printf("+%d points added to total score\n", point);

			system("pause");
			system("cls");
		}

	}
}
//This function controls the level 4 difficulty of the game. It increases the points 
//after each question while getting harder after a certain amount of quetions.
void level_4_problem(Stats user, int *total_points_ptr)
{
	int term1 = 0, term2 = 0, term3 = 0, denominator = 0, numerator = 0, question_index = 0;
	int question_number = 1;
	char sign1 = '\0', sign2 = '\0', user_division_notation = '\0';
	int user_answer = 0, score = 1, difficulty = 0, point = 0, problemtype = 0;
	int user_numerator = 0, user_denominator = 0;
	int answer = 0;

	for (question_index = 0; question_index < 10; question_index++)
	{
		if (score < 4) // adjusts difficulty after 4 correct
		{
			problemtype = rand() % 3; //creates 3 types of problems for difficulty 1
			difficulty = 1;
			term1 = generate_positive_negative_term();
			term2 = generate_positive_negative_term();
			term3 = generate_positive_negative_term();
			if (problemtype = 0)
			{
				sign1 = '+';
				sign2 = '*';
				answer = term1 + term2 * term3;
			}
			if (problemtype = 1)
			{
				sign1 = '-';
				sign2 = '*';
				answer = term1 + term2 * term3;
			}
			if (problemtype = 2)
			{
				sign1 = '*';
				sign2 = '*';
				answer = term1 * term2 * term3;
			}
		}
		else if ((score >= 4) && (score < 7))
		{
			problemtype = rand() % 2;
			difficulty = 2;
			term1 = generate_positive_negative_term();
			term2 = generate_positive_negative_term();
			term3 = generate_positive_negative_term();
			if (problemtype = 0)
			{
				sign1 = '/';
				sign2 = '*';
				while (term2 == 0)
				{
					term2 = generate_positive_negative_term();
				}
				numerator = (term1 * term3);
				denominator = term2;

			}
			if (problemtype = 1)
			{
				sign1 = '*';
				sign2 = '/';
				while (term3 == 0)
				{
					term3 = generate_positive_negative_term();
				}
				numerator = term1 * term2;
				denominator = term3;
			}
		}
		else
		{
			difficulty = 3;
			sign1 = '/';
			sign2 = '/';
			term1 = generate_positive_negative_term();
			term2 = generate_positive_negative_term();
			term3 = generate_positive_negative_term();
			while ((term2 == 0) || (term3 == 0))
			{
				term2 = generate_positive_negative_term();
				term3 = generate_positive_negative_term();
			}
			denominator = term2 * term3;
			numerator = term1;
		}

		if (score < 4)
		{
			printf("Question %d: ", question_number);
			printf("%d %c %d %c %d = ", term1, sign1, term2, sign2, term3);
			scanf("%d", &user_answer);

			if (user_answer != answer) // incorrect
			{
				printf("That is incorrect.\n");
				printf("The correct answer was %d\n", answer);

				point = control_total_points(difficulty, total_points_ptr, 0);
				score--; // decreases difficulty within level
				question_number++;

				printf("-%d points subtracted from total score\n", point);

				system("pause");
				system("cls");
			}
			else // correct
			{
				printf("That is correct!\n");

				point = control_total_points(difficulty, total_points_ptr, 1);
				score++; // increases difficulty within level
				question_number++;

				printf("+%d points added to total score\n", point);

				system("pause");
				system("cls");
			}
		}
		else
		{
			do
			{
				printf("Question %d\n", question_number);
				printf("Example Answer: 3 * 2 / 4 =  6 / 4. (This is an unsimplified fraction)\n");
				printf("%d %c %d %c %d = ", term1, sign1, term2, sign2, term3);
				scanf("%d %c %d", &user_numerator, &user_division_notation, &user_denominator);

				if (user_division_notation != '/') // makes sure the user uses '/'
				{
					printf("You need a '/' seperating your digits.\n");
					printf("Pay attention and try agian.\n");
				}
			} while (user_division_notation != '/');

			if ((user_numerator != numerator) || (user_denominator != denominator))
			{
				if (user_numerator != numerator) // incorrect
				{
					printf("Your first digit was wrong.\n");
					printf("The correct answer was (%d) / %d\n", numerator, denominator);
					system("pause");
				}
				if (user_denominator != denominator)
				{
					printf("Your second digit was wrong.\n");
					printf("The correct answer was %d / (%d)\n", numerator, denominator);
					system("pause");
				}
				point = control_total_points(difficulty, total_points_ptr, 0);
				score--; // decreases difficulty within level
				question_number++;

				printf("-%d points subtracted from total score\n", point);
				system("cls");
			}
			else // correct
			{
				printf("That is correct!\n");

				point = control_total_points(difficulty, total_points_ptr, 1);
				score++; // increases difficulty within level
				question_number++;

				printf("+%d points added to total score\n", point);

				system("pause");
				system("cls");
			}
		}
	}
}
//This function controls the level 5 difficulty of the game. It increases the points 
//after each question while getting harder after a certain amount of quetions.
void level_5_problem(Stats user, int *total_points_ptr) //begin level 5
{
	int term1 = 0, term2 = 0, term3 = 0, term4 = 0, denominator = 0, numerator = 0, question_index = 0;
	int question_number = 1;
	char sign1 = '\0', sign2 = '\0', sign3 = '\0', user_division_notation = '\0';
	int user_answer = 0, score = 1, difficulty = 0, point = 0, problemtype = 0;
	int user_numerator = 0, user_denominator = 0;
	int answer = 0;

	for (question_index = 0; question_index < 10; question_index++)
	{
		if (score < 4) // adjusts the problem generated based on the users amount of correct answers
		{
			problemtype = rand() % 3;
			difficulty = 1;
			if (problemtype = 0)
			{
				sign1 = '+';
				sign2 = '+';
				sign3 = '+';
				term1 = generate_2_digit_term();
				term2 = generate_2_digit_term();
				term3 = generate_2_digit_term();
				term4 = generate_2_digit_term();
				answer = term1 + term2 + term3 +term4;
			}
			if (problemtype = 1)
			{
				sign1 = '-';
				sign2 = '-';
				sign3 = '-';
				term1 = generate_2_digit_term();
				term2 = generate_2_digit_term();
				term3 = generate_2_digit_term();
				term4 = generate_2_digit_term();
				answer = term1 - term2 - term3 - term4;
			}
			if (problemtype = 2)
			{
				sign1 = '-';
				sign2 = '+';
				sign3 = '-';
				term1 = generate_2_digit_term();
				term2 = generate_3_digit_term();
				term3 = generate_3_digit_term();
				term4 = generate_2_digit_term();
				answer = term1 - term2 + term3 - term4;
			}
		}
		else if ((score >= 4) && (score < 7))
		{
			problemtype = rand() % 3;
			difficulty = 2;
			if (problemtype = 0)
			{
				sign1 = '*';
				sign2 = '+';
				sign3 = '*';
				term1 = generate_3_digit_term();
				term2 = generate_2_digit_term();
				term3 = generate_3_digit_term();
				term4 = generate_2_digit_term();
				answer = term1 * term2 + term3 * term4;
			}
			if (problemtype = 1)
			{
				sign1 = '*';
				sign2 = '*';
				sign3 = '+';
				term1 = generate_2_digit_term();
				term2 = generate_2_digit_term();
				term3 = generate_3_digit_term();
				term4 = generate_3_digit_term();
				answer = term1 * term2 * term3 + term4;
			}
			if (problemtype = 2)
			{
				sign1 = '*';
				sign2 = '*';
				sign3 = '*';
				term1 = generate_2_digit_term();
				term2 = generate_3_digit_term();
				term3 = generate_2_digit_term();
				term4 = generate_3_digit_term();
				answer = term1 * term2 * term3 * term4;
			}
		}
		else
		{
			problemtype = rand() % 3;
			difficulty = 3;
			if (problemtype = 0)
			{
				sign1 = '*';
				sign2 = '*';
				sign3 = '/';
				term1 = generate_3_digit_term();
				term2 = generate_3_digit_term();
				term3 = generate_3_digit_term();
				term4 = generate_3_digit_term();
				numerator = term1*term2*term3;
				denominator = term4;
			}
			if (problemtype = 1)
			{
				sign1 = '/';
				sign2 = '*';
				sign3 = '*';
				term1 = generate_3_digit_term();
				term2 = generate_3_digit_term();
				term3 = generate_3_digit_term();
				term4 = generate_3_digit_term();
				numerator = term1*term4*term3;
				denominator = term2;
			}
			if (problemtype = 2)
			{
				sign1 = '*';
				sign2 = '/';
				sign3 = '*';
				term1 = generate_3_digit_term();
				term2 = generate_3_digit_term();
				term3 = generate_3_digit_term();
				term4 = generate_3_digit_term();
				numerator = term1*term2*term4;
				denominator = term3;
			}
		}

		if (score < 7)
		{
			printf("Question %d: ", question_number);
			printf("%d %c %d %c %d %c %d= ", term1, sign1, term2, sign2, term3, sign3, term4);
			scanf("%d", &user_answer);

			if (user_answer != answer) // incorrect
			{
				printf("That is incorrect.\n");
				printf("The correct answer was %d\n", answer);

				point = control_total_points(difficulty, total_points_ptr, 0);
				score--; // decreases difficulty within level
				question_number++;

				printf("-%d points subtracted from total score\n", point);

				system("pause");
				system("cls");
			}
			else // correct
			{
				printf("That is correct!\n");

				point = control_total_points(difficulty, total_points_ptr, 1);
				score++; // increases difficulty within level
				question_number++;

				printf("+%d points added to total score\n", point);

				system("pause");
				system("cls");
			}
		}
		else
		{
			do
			{
				printf("Question %d\n", question_number);
				printf("Example Answer: 3 * 2 / 4 =  6 / 4. (This is an unsimplified fraction)\n");
				printf("%d %c %d %c %d %c %d= ", term1, sign1, term2, sign2, term3, sign3, term4);
				scanf("%d %c %d", &user_numerator, &user_division_notation, &user_denominator); 

				if (user_division_notation != '/') // makes sure the user uses '/'
				{
					printf("You need a '/' seperating your digits.\n");
					printf("Pay attention and try agian.\n");
				}
			} while (user_division_notation != '/');

			if ((user_numerator != numerator) || (user_denominator != denominator))
			{
				if (user_numerator != numerator) // incorrect
				{
					printf("Your first digit was wrong.\n");
					printf("The correct answer was (%d) / %d\n", numerator, denominator);
					system("pause");
				}
				if (user_denominator != denominator)
				{
					printf("Your second digit was wrong.\n");
					printf("The correct answer was %d / (%d)\n", numerator, denominator);
					system("pause");
				}
				point = control_total_points(difficulty, total_points_ptr, 0);
				score--; // decreases difficulty within level
				question_number++;

				printf("-%d points subtracted from total score\n", point);
				system("cls");
			}
			else // correct
			{
				printf("That is correct!\n");

				point = control_total_points(difficulty, total_points_ptr, 1);
				score++; // increases difficulty within level
				question_number++;

				printf("+%d points added to total score\n", point);

				system("pause");
				system("cls");
			}
		}
	}
}
//this function prints the intials and the total points to the stats file
void print_stats(FILE *output, Stats SUPERuser, char initials[]) //prints stats to file
{
	fprintf(output, "Player: %c%c%c\n", initials[0], initials[1], initials[2]); //accepts user initals
	fprintf(output, "Total Points: %d\n", SUPERuser.points); //accepts user points
}
//this function prints my super lame game logo
void print_SUPERMATH(void)
{
	printf(" *        * *    *  \n");
	printf("***  ***   *    *   \n");
	printf(" *        * *  *    \n"); 
	// :)
}
//this function runs the math tutorial. This is a very simple and repetitive function. 
//It does not contain many comments because it is nearly self-explanatory.
void run_math_tutorial(void)
{
	int addition_ones = 0, addition_ones_t2 = 0, add_answer = 0;
	int subtract_ones = 0, subtract_ones_t2 = 0, subtract_answer = 0;
	int multiply_ones = 0, multiply_ones_t2 = 0, multiply_answer = 0;
	int divide_ones = 0, divide_ones_t2 = 0, divide_true = 0;
	char divide_answer = '\0';

	printf("Let's add some numbers.\n");
	printf("Let's add term1 (6) + term2 (4) = ?\n");
	printf("How many ones make up term1?\n");
	do
	{
		scanf(" %d", &addition_ones);
		if (addition_ones == 6)
		{
			printf("Correct! 6 = (1+1+1+1+1+1).\n");
		}
		else
		{
			printf("Thats not right. Recall: 6 = (1+1+1+1+1+1).\n");
			printf("How many ones make up term1?\n");
		}
	} while (addition_ones != 6);
	system("pause");
	system("cls");
	printf("Let's add term1 (6) + term2 (4) = ?\n");
	printf("How many ones make up term2?\n");
	do
	{
		scanf(" %d", &addition_ones_t2);
		if (addition_ones_t2 == 4)
		{
			printf("Correct! 4 = (1+1+1+1).\n");
		}
		else
		{
			printf("Thats not right. Recall: 4 = (1+1+1+1).\n");
			printf("How many ones make up term2?\n");
		}
	} while (addition_ones_t2 != 4);
	system("pause");
	system("cls");
	printf("Let's put together what we know.\n");
	printf("Let's add 6 + 4 = ?\n");
	do
	{
		scanf(" %d", &add_answer);
		if (add_answer == 10)
		{
			printf("Correct! 6 + 4 = 10.\n");
		}
		else
		{
			printf("Thats not right. Add the total values Recall: 4 = (1+1+1+1) and 6 = (1+1+1+1+1+1).\n");
			printf("Let's add 6 + 4 = ?\n");
		}
	} while (add_answer != 10); //check to see if the user has learned how to do addition
	system("pause");
	system("cls");
	printf("Lets move to subtraction...\n");
	system("pause");
	system("cls");

	printf("Let's subtract some numbers.\n");
	printf("Let's subtract term1 (5) - term2 (2) = ?\n");
	printf("How many ones make up term1?\n");
	do
	{
		scanf(" %d", &subtract_ones);
		if (subtract_ones == 5)
		{
			printf("Correct! 5 = (1+1+1+1+1).\n");
		}
		else
		{
			printf("Thats not right. Recall: 5 = (1+1+1+1+1).\n");
			printf("How many ones make up term1?\n");
		}
	} while (subtract_ones != 5);
	system("pause");
	system("cls");
	printf("Let's subtract term1 (5) - term2 (2) = ?\n");
	printf("How many ones make up term2?\n");
	do
	{
		scanf(" %d", &subtract_ones_t2);
		if (subtract_ones_t2 == 2)
		{
			printf("Correct! 2 = (1+1).\n");
		}
		else
		{
			printf("Thats not right. Recall: 2 = (1+1).\n");
			printf("How many ones make up term2?\n");
		}
	} while (subtract_ones_t2 != 2);
	system("pause");
	system("cls");
	printf("Let's put together what we know.\n");
	printf("Let's subtract 5 - 2 = ?\n");
	do
	{
		scanf(" %d", &subtract_answer);
		if (subtract_answer == 3)
		{
			printf("Correct! 5 - 2 = 3.\n");
		}
		else
		{
			printf("Thats not right. Take away the total values of term2. Recall: 5 = (1+1+1+1+1) and 2 = (1+1).\n");
			printf("Let's subtract 5 - 2 = ?\n");
		}
	} while (subtract_answer != 3); //check to see if the user has learned how to do subtraction
	system("pause");
	system("cls");
	printf("Lets move to multiplication...\n");
	system("pause");
	system("cls");

	printf("Let's multiply some numbers.\n");
	printf("Let's mulitiply term1 (4) * term2 (5) = ?\n");
	printf("How many times will term1 be multiplied?\n");
	do
	{
		scanf(" %d", &multiply_ones);
		if (multiply_ones == 5)
		{
			printf("Correct! 4 will be multiplied 5 times in 4*5..\n");
		}
		else
		{
			printf("Thats not right. Multiplication is simply adding the first term (4) term2 amount of times.\n");
			printf("How many times will term1 be multiplied?\n");
		}
	} while (multiply_ones != 5);
	system("pause");
	system("cls");
	printf("Let's mulitiply term1 (4) * term2 (5) = ?\n");
	printf("What is 4 added 5 times?\n");
	do
	{
		scanf(" %d", &multiply_ones_t2);
		if (multiply_ones_t2 == 20)
		{
			printf("Correct! 4 added 5 times = (4+4+4+4+4).\n");
		}
		else
		{
			printf("Thats not right. If you were to add the number 4 five times, it would look like (4+4+4+4+4).\n");
			printf("What is 4 added 5 times?\n");
		}
	} while (multiply_ones_t2 != 20);
	system("pause");
	system("cls");
	printf("Let's put together what we know.\n");
	printf("What is 4 * 5 ?\n");
	do
	{
		scanf(" %d", &multiply_answer);
		if (multiply_answer == 20)
		{
			printf("Correct! 4 * 5 = 20.\n");
		}
		else
		{
			printf("Thats not right. Recall: If you were to add the number 4 five times, it would look like (4+4+4+4+4).\n");
			printf("What is 4 * 5 ?\n");
		}
	} while (multiply_answer != 20); //check to see if the user has learned how to do multiplication
	system("pause");
	system("cls");

	printf("Let's divide some numbers.\n");
	printf("Let's divide term1 (4) / term2 (3) = ?\n");
	printf("How many times does term2 (3) go into term1 (4)?\n");
	do
	{
		scanf(" %d", &divide_ones);
		if (divide_ones == 1)
		{
			printf("Correct! 3 goes into 4 one time in 4/5.\n");
		}
		else
		{
			printf("Thats not right. Think  about the fact 4 is bigger than 3. Three fits inside 4 at least one time..\n");
			printf("How many times does term2 (3) go into term1 (4)?\n");
		}
	} while (divide_ones != 1);
	system("pause");
	system("cls");
	printf("Let's divide term1 (4) / term2 (3) = ?\n");
	printf("What is left over when you add 3 into 4 the max number of times?\n");
	do
	{
		scanf(" %d", &divide_ones_t2);
		if (divide_ones_t2 == 1)
		{
			printf("Correct! 4-(3*1) = 1 OR, once we add 3, we have one value left until we reach 4..\n");
		}
		else
		{
			printf("Thats not right. Try subtracting term1 by term2 multiplied by the number of times 2 goes into 1 to get a remainder.\n");
			printf("What is 4 added 5 times?\n");
		}
	} while (divide_ones_t2 != 1);
	system("pause");
	system("cls");
	printf("Let's put together what we know.\n");
	printf("What is 4 / 3 ? Enter the letter of the correct multiple choice problem.\n");
	printf("A. 1R1.\n");
	printf("B. 1R0.\n");
	printf("C. 0R1.\n");
	printf("D. 0R4.\n");
	do
	{
		scanf(" %c", &divide_answer);
		if ((divide_answer == 'A') || (divide_answer == 'a'))
		{
			printf("Correct! 4 / 3 = 1R1.\n");
			divide_true = 1;
		}
		else
		{
			printf("Thats not right. Recall: 3 goes into 4 one time. Also recall that once we add 3 there is only one number left until we get to 4.\n");
			printf("What is 4 / 3 ?\n");
		}
	} while (divide_true != 1); //check to see if the user has learned how to do division
	system("pause");
	system("cls");
}